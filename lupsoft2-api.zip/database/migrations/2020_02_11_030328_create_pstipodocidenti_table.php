<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePstipodocidentiTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pstipodocidenti', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('codtipdocid');
            $table->string('nomtipodocumento');
            $table->string('nitempresa',30);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pstipodocidenti');
    }
}
