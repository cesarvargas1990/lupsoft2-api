# lumen-auth-example

## Usage

-   `git clone https://github.com/ndiecodes/lumen-auth-example.git auth-api`
-   `cd auth-api`
-   `composer install`
-   `php artisan jwt:secret`
-   `php artisan migrate`
-   `php -S localhost:8000 -t public`
